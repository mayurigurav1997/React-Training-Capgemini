import {createContext} from 'react';


let HolidayContext = createContext();

export default HolidayContext;